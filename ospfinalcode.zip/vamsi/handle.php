<!doctype html>



<?php



session_start();


if($_SESSION['loggedin']!=true){
  session_destroy();
  header("location: notfound.php");
  
}







?>


<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,200;0,300;0,400;1,800&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link rel="stylesheet" href="cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

 <style>

  body{
  font-family: 'Public Sans', sans-serif;
  font-weight: 400;
}

.navbar-brand{
  font-family: 'Public Sans', sans-serif;
  font-weight: 800;
  font-size: 25px;

}

nav{
  color:white;
  background-color: #FC7174;
}

#img{
  width: 40%;
  height: auto;
}

.full-height{
   margin-top: 50px;
   }


   .bhns{
    margin-left: 50px;
   }

 </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark ">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i><b>Bookbyers</b></i></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" href="find.php">Find Roommates</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="moredetails.php">Create a room</a>
        </li>
       
      </ul>
      <span class="navbar-text" style="margin-right:40px">
        Logged in as <?php echo $_SESSION['user_first_name']; ?>
      </span>
      <span class="navbar-text active">
        <a  style="text-decoration: none" href="logout.php">Logout</a>
        
      </span>
      </span>
    </div>
  </div>
</nav>


<?php

include 'partials/_dbconnect.php';

$email= $_SESSION['user_email_address'];

$sql="SELECT `id` FROM `basic` WHERE `email`='$email'";

$result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);

$row = mysqli_fetch_assoc($result);

$myid = $row["id"];

$sql="SELECT `access_key` from `roomdetails` WHERE `room_owner_id`='$myid'";


$result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);

$row = mysqli_fetch_assoc($result);
error_reporting(E_ERROR | E_PARSE);
$access_key = $row["access_key"];




if(isset($_GET['approve'])){
    $sno = $_GET['approve'];

    
    
    
    include 'partials/_dbconnect.php';

    $sql= "UPDATE `room` SET `approved`= TRUE WHERE `room_owner_id`='$myid' AND `room_mate_id`='$sno'";
    $result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);;

echo "
<div class='alert alert-success alert-dismissible fade show' role='alert'>
Approved succesfully
<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>";
}

if(isset($_GET['reject'])){
  $sno = $_GET['reject'];

  
  
  
  include 'partials/_dbconnect.php';

  $sql= "DELETE from room WHERE `room_owner_id`='$myid' AND `room_mate_id`='$sno'";
  $result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);;

echo "
<div class='alert alert-warning alert-dismissible fade show' role='alert'>
Request Rejected
<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>";
}

  










?>














<div class=" container full-height d-flex flex-column bd-highlight mb-3" style="height: 200px;">
  <h1>Manage Requests for room ID : <?php if($access_key){echo $access_key;} else {echo "";}?></h1>
  <br>

  
  <div class="container my-4">


    <table class="table table-striped" id="myTable">
      <thead>
        <tr>
          <th scope="col">Phone Number</th>
          <th scope="col">Roll Number</th>
          <th scope="col">Username</th>
          <th scope="col">Email</th>
          
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php 
         include 'partials/_dbconnect.php';
          $sql = "SELECT * 
          FROM room
          JOIN basic
          ON room.room_mate_id=basic.id where room.room_owner_id='$myid' AND room.approved=0";

// WHERE `email`!='$email'



          $result = mysqli_query($conn, $sql);
        
          while($row = mysqli_fetch_assoc($result)){
            
            echo "<tr>
            <td scope='row'>". $row['phno'] . "</td>
            <td>". $row['rollno'] . "</td>
            <td>". $row['username'] . "</td>
            <td>". $row['email'] . "</td>
            
            <td> <button class='approve btn btn-sm btn-success'  id=".$row['room_mate_id'].">Approve</button> <button class='reject btn btn-sm btn-warning' onclick='fun2()' id=".$row['room_mate_id'].">Reject</button> </td>
          </tr>";
        } 
          ?>


      </tbody>
    </table>
  </div>
</div>
<script>







approves = document.getElementsByClassName('approve');
    Array.from(approves).forEach((element) => {
      element.addEventListener("click", (e) => {
        console.log("approve ");
        sno = e.target.id;
        console.log(sno);

        if (confirm("Are you sure you want to approve the request?")) {
          console.log("yes");
          window.location = `/vamsi/handle.php?approve=${sno}`;
          // TODO: Create a form and use post request to submit a form
        }
        else {
          console.log("no");
        }
      })
    })



    rejects = document.getElementsByClassName('reject');
    Array.from(rejects).forEach((element) => {
      element.addEventListener("click", (e) => {
        console.log("delete ");
        sno = e.target.id;
        console.log(sno);

        if (confirm("Are you sure you want to reject the request?")) {
          console.log("yes");
          window.location = `/vamsi/handle.php?reject=${sno}`;
          // TODO: Create a form and use post request to submit a form
        }
        else {
          console.log("no");
        }
      })
    })





   









</script>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>




    <script>


$(document).ready( function () {
    $('#myTable').DataTable();
} );






</script>
  </body>
</html>