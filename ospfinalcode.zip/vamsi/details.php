<!doctype html>




<?php

session_start();

if($_SESSION['loggedin']!=true){
    session_destroy();
    header("location: notfound.php");
    
}

?>




<?php
    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $fname = $_POST['fname'];
        $lname = $_POST['lname'];
        $uname = $_POST['username'];
        $rno = $_POST['rno'];
        $gender = $_POST['gender'];
        $state = $_POST['state'];
        $pno = $_POST['pno'];
        $email= $_SESSION['user_email_address'];
      



        include 'partials/_dbconnect.php';

      
echo $fname;
echo $lname;
echo $uname;
echo $rno;
echo $gender;
echo $state;
echo $pno;

// $sql = "INSERT INTO `basic` (`phno`, `rollno`, `username`) VALUES ('$pno', '$rno', '$uname') WHERE `email`='$email'";

 $sql= "UPDATE `basic` SET `phno`='$pno',`rollno`='$rno',`username`='$uname' WHERE `email`='$email'";
        $result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);;


 $sql= "SELECT id FROM `basic` WHERE `email`='$email'";
        $result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);;
        $row = mysqli_fetch_assoc($result);

$ans = $row["id"];




echo $ans;


 $sql = "INSERT INTO `more` (`id`,`firstname`, `lastname`, `gender`, `state`, `email`) VALUES ('$ans','$fname', '$lname', '$gender', '$state', '$email')";
        $result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);;



        header("location: dashboard.php");





    }

    
?>





















<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,200;0,300;0,400;1,800&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

 <style>

  body{
  font-family: 'Public Sans', sans-serif;
  font-weight: 400;
}

.navbar-brand{
  font-family: 'Public Sans', sans-serif;
  font-weight: 800;
  font-size: 25px;

}

nav{
  color:white;
  background-color: #FC7174;
}

#img{
  width: 40%;
  height: auto;
}

.full-height{
   margin-top: 150px;
   }

 </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark ">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i><b>Bookbyers</b></i></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link disabled" href="#">Find Roommates</a>
        </li>
        <li class="nav-item">
          <a class="nav-link disabled" href="#">Create a room</a>
        </li>
       
      </ul>
      <span class="navbar-text active">
        <a  style="text-decoration: none" href="logout.php">Logout</a>
        
      </span>
    </div>
  </div>
</nav>


<div class=" container full-height d-flex align-items-center flex-column bd-highlight mb-3" style="height: 200px;">
  
  <form class="row g-3" method="post" action="details.php">
  <div class="col-md-3">
    <label for="validationServer01" class="form-label">First name</label>
    <input type="text" class="form-control " name="fname" value="Vamsi" required>
    <div class="valid-feedback">
      Looks good!
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationServer02" class="form-label">Last name</label>
    <input type="text" class="form-control" name="lname" value="Krishna" required>
    <div class="valid-feedback">
      Looks good!
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationServerUsername" class="form-label">Username</label>
    <div class="input-group has-validation">
      <span class="input-group-text" id="inputGroupPrepend3">@</span>
      <input type="text" class="form-control " name="username" required>
      <div id="validationServerUsernameFeedback" class="invalid-feedback">
        Please choose a username.
      </div>
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationServer02" class="form-label">Phone Number</label>
    <input type="number" class="form-control" name="pno" value="8074493156" required>
    <div class="valid-feedback">
      Looks good!
    </div>
  </div>
  <div class="col-md-6">
    <label for="validationServer03" class="form-label">Roll Number</label>
    <input type="text" class="form-control" name="rno"  required>
    <div id="validationServer03Feedback" class="invalid-feedback">
      Please provide a valid roll number.
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationServer04" class="form-label">Gender</label>
    <select class="form-select"  name="gender"  required>
      <option selected disabled value="">Choose...</option>
      <option>Male</option>
      <option>Female</option>
    </select>
    <div id="validationServer04Feedback" class="invalid-feedback">
      Please select a valid gender.
    </div>
  </div>
  <div class="col-md-3">
    <label for="validationServer05" class="form-label">State</label>
    <select class="form-select "  name="state"  aria-describedby="validationServer04Feedback" required>
      <option selected disabled value="">Choose...</option>
      <option>Tamil Nadu</option>
      <option>Telangana</option>
      <option>Andhra Pradesh</option>
    </select>
  </div>
  <div class="col-12">
    
    <div class="alert alert-warning" role="alert">
  Please read the <a href="#">terms and conditions</a> before you submit

    </div>

  </div>
  <div class="col-12">
    <button class="btn btn-primary" type="submit">Submit details</button>
  </div>
</form>
</div>

    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>