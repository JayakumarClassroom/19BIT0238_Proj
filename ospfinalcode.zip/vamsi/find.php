<!doctype html>



<?php



session_start();

if($_SESSION['loggedin']!=true){
  session_destroy();
  header("location: notfound.php");
  
}

?>


<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,200;0,300;0,400;1,800&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">
<link rel="stylesheet" href="cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">

 <style>

  body{
  font-family: 'Public Sans', sans-serif;
  font-weight: 400;
}

.navbar-brand{
  font-family: 'Public Sans', sans-serif;
  font-weight: 800;
  font-size: 25px;

}

nav{
  color:white;
  background-color: #FC7174;
}

#img{
  width: 40%;
  height: auto;
}

.full-height{
   margin-top: 50px;
   }


   .bhns{
    margin-left: 50px;
   }

 </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark ">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i><b>Bookbyers</b></i></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" href="#">Find Roommates</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="moredetails.php">Create a room</a>
        </li>
       
      </ul>
      <span class="navbar-text" style="margin-right:40px">
        Logged in as <?php echo $_SESSION['user_first_name']; ?>
      </span>
      <span class="navbar-text active">
        <a  style="text-decoration: none" href="logout.php">Logout</a>
        
      </span>
      </span>
    </div>
  </div>
</nav>


<?php


$email= $_SESSION['user_email_address'];



if(isset($_GET['edit'])){
    $sno = $_GET['edit'];
    
    
    include 'partials/_dbconnect.php';

$sql="SELECT `room_owner_id` FROM `roomdetails` WHERE `access_key`='$sno'";

$result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);

$row = mysqli_fetch_assoc($result);

$ans1 = $row["room_owner_id"];



$sql="SELECT `id` FROM `basic` WHERE `email`='$email'";

$result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);

$row = mysqli_fetch_assoc($result);

$ans2 = $row["id"];







$sql = "INSERT INTO `room` (`room_owner_id`, `room_mate_id`) VALUES ('$ans1', '$ans2') ";
$result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);

echo "
<div class='alert alert-success alert-dismissible fade show' role='alert'>
Request sent succesfully
<button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>";
}


  










?>














<div class=" container full-height d-flex flex-column bd-highlight mb-3" style="height: 200px;">
  <h1>Find rooms</h1>
  <br>

  
  <div class="container my-4">


    <table class="table table-striped" id="myTable">
      <thead>
        <tr>
          <th scope="col">Room-id</th>
          <th scope="col">Room Owner</th>
          <th scope="col">Preferred Block</th>
          <th scope="col">Preferred Room Type</th>
          <th scope="col">Hometown</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php 
         include 'partials/_dbconnect.php';
          $sql = "SELECT * 
          FROM more
          JOIN roomdetails
          ON more.id=roomdetails.room_owner_id 
WHERE `email`!='$email'";




          $result = mysqli_query($conn, $sql);
        
          while($row = mysqli_fetch_assoc($result)){
            
            echo "<tr>
            <td scope='row'>". $row['access_key'] . "</td>
            <td>". $row['firstname'] . "</td>
            <td>". $row['preferred_block'] . "</td>
            <td>". $row['type'] . "</td>
            <td>". $row['state'] . "</td>
            <td> <button class='edit btn btn-sm btn-primary' onclick='fun()' id=".$row['access_key'].">Request to join</button>  </td>
          </tr>";
        } 
          ?>


      </tbody>
    </table>
  </div>
</div>
<script>







edits = document.getElementsByClassName('edit');
    Array.from(edits).forEach((element) => {
      element.addEventListener("click", (e) => {
        console.log("edit ");
        sno = e.target.id;
        console.log(sno);

        if (confirm("Are you sure you want to send the request?")) {
          console.log("yes");
          window.location = `/vamsi/find.php?edit=${sno}`;
          // TODO: Create a form and use post request to submit a form
        }
        else {
          console.log("no");
        }
      })
    })


   









</script>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js"
    integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n"
    crossorigin="anonymous"></script>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
    <script src="//cdn.datatables.net/1.10.20/js/jquery.dataTables.min.js"></script>




    <script>


$(document).ready( function () {
    $('#myTable').DataTable();
} );



</script>
  </body>
</html>