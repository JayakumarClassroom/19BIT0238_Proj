<?php
session_start();

if($_SESSION['loggedin']!=true){
    session_destroy();
    header("location: notfound.php");
    
}
else{
    echo "Yo you are permitted";
    echo $_SESSION['newstring'];
}

?>