<?php

/* 
Ways to connect to a MySQL Database
1. MySQLi extension
2. PDO
*/
// Connecting to the Database
$servername = "localhost";
$username = "root";
$password = "";
$database = "review";

// Create a connection
$conn = mysqli_connect($servername, $username, $password, $database);



?>