<?php

//index.php

//Include Configuration File
include('config.php');

$login_button = '';

//This $_GET["code"] variable value received after user has login into their Google Account redirct to PHP script then this variable value has been received
if(isset($_GET["code"]))
{
 //It will Attempt to exchange a code for an valid authentication token.
 $token = $google_client->fetchAccessTokenWithAuthCode($_GET["code"]);

 //This condition will check there is any error occur during geting authentication token. If there is no any error occur then it will execute if block of code/
 if(!isset($token['error']))
 {
  //Set the access token used for requests
  $google_client->setAccessToken($token['access_token']);

  //Store "access_token" value in $_SESSION variable for future use.
  $_SESSION['access_token'] = $token['access_token'];

  //Create Object of Google Service OAuth 2 class
  $google_service = new Google_Service_Oauth2($google_client);

  //Get user profile data from google
  $data = $google_service->userinfo->get();

  //Below you can find Get profile data and store into $_SESSION variable
  if(!empty($data['given_name']))
  {
   $_SESSION['user_first_name'] = $data['given_name'];
  }

  if(!empty($data['family_name']))
  {
   $_SESSION['user_last_name'] = $data['family_name'];
  }

  if(!empty($data['email']))
  {
   $_SESSION['user_email_address'] = $data['email'];
  }

  if(!empty($data['gender']))
  {
   $_SESSION['user_gender'] = $data['gender'];
  }

  if(!empty($data['picture']))
  {
   $_SESSION['user_image'] = $data['picture'];
  }


  // $_SESSION['newstring'] = substr($_SESSION['user_email_address'], -16);


  // echo $_SESSION['newstring'];
  // if($_SESSION['newstring']=='vitstudent.ac.in'){
    $_SESSION['loggedin']=true;



include 'partials/_dbconnect.php';


$email= $_SESSION['user_email_address'];


$sql= "SELECT id FROM `basic` WHERE `email`='$email'";
        $result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);;
        $row = mysqli_fetch_assoc($result);

$ans = $row["id"];



if(!$ans){

// Sql query to be executed
$sql = "INSERT INTO `basic` (`email`) VALUES ('$email')";
$result = mysqli_query($conn, $sql);





header("location: details.php");



}










  // }
// else{

   //  session_destroy();
   // header('location:notfound.php');

// }
   
  
  
 



 }
}

//This is for check user has login into system by using Google account, if User not login into system then it will execute if block of code and make code for display Login link for Login using Google account.
if(!isset($_SESSION['access_token']))
{
 //Create a URL to obtain user authorization
 $login_button = '<a href="'.$google_client->createAuthUrl().'"><img src="./images/signin.png" /></a>';
}

?>






<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,200;0,300;0,400;1,800&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />

    <script src="https://cdn.jsdelivr.net/npm/typeit@7.0.4/dist/typeit.min.js"></script>

 <style>

  body{
  font-family: 'Public Sans', sans-serif;
  font-weight: 400;
}

.navbar-brand{
  font-family: 'Public Sans', sans-serif;
  font-weight: 800;
  font-size: 25px;

}

nav{
  color:white;
  background-color: #FC7174;
}

#img{
  width: 40%;
  height: auto;
}

.full-height{
   margin-top: 70px;
   }



   #anii {
  

  animation: backInRight; /* referring directly to the animation's @keyframe declaration */
  animation-duration: 2s; /* don't forget to set a duration! */
}

.card {
  

  animation: pulse; /* referring directly to the animation's @keyframe declaration */
  animation-duration: 2s; /* don't forget to set a duration! */
}

/* [1] The container */

/* [2] Transition property for smooth transformation of images */
.card:hover {
  transform: scale(1.03); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
  background-color: #FC7174;
  transition: transform .5s ease;
  color: white;
}





 </style>
  </head>
  <body>
  <?php




if(!$_SESSION['loggedin']){
  header('location: notfound.php');
}


?>
    <nav class="navbar navbar-expand-lg navbar-dark ">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><i><b>Bookbyers</b></i></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" href="#">Find Roommates</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="#">Create a room</a>
        </li>
       
      </ul>
      <span class="navbar-text" style="margin-right:40px">
        Logged in as <?php echo $_SESSION['user_first_name']; ?>
      </span>
      <span class="navbar-text active">
        <a  style="text-decoration: none" href="logout.php">Logout</a>
        
      </span>
    </div>
  </div>
</nav>





<div class="container" style="margin-top: 50px">


<?php

if(isset($_SESSION['flag'])){
  echo "
  <div class='alert alert-success alert-dismissible fade show' role='alert'>
  Room Succesfully created!
  <button type='button' class='btn-close' data-bs-dismiss='alert' aria-label='Close'></button>
</div>";


unset($_SESSION['flag']);



}
?>



<p class="h1">Dashboard</p>
<hr>
  <div class="row">
    <div class="col">
      <div class="card" style="width: 100%" onclick="myFunction1()">
  <img src="search.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Find Room</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    
  </div>
</div>
    </div>
    <div class="col">
      <div class="card" style="width: 100%" onclick="myFunction2()">
  <img src="create.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Create a room</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    
  </div>
</div>
    </div>
    <div class="col">
      <div class="card" style="width: 100%" onclick="myFunction3()">
  <img src="s2.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Manage Rooms</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    
  </div>
</div>
    </div>
  </div>
</div>
<br>
<br>
<br>
<br>

<script>

function myFunction1() {
  window.location = "http://localhost/vamsi/find.php";
}
function myFunction2() {
  window.location = "http://localhost/vamsi/moredetails.php";
}

function myFunction3() {
  window.location = "http://localhost/vamsi/view.php";
}



</script>
























  
 


    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->





  </body>
</html>
