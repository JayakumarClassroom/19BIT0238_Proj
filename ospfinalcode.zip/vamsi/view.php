<!doctype html>

<?php

session_start();

if($_SESSION['loggedin']!=true){
  session_destroy();
  header("location: notfound.php");
  
}



    if ($_SERVER['REQUEST_METHOD'] == 'POST'){
        $beds = $_POST['beds'];
        $block = $_POST['block'];
        $type = $_POST['type'];



echo $beds;

echo $block;

echo $type;

include 'partials/_dbconnect.php';

$email= $_SESSION['user_email_address'];


$sql= "SELECT id FROM `basic` WHERE `email`='$email'";
        $result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);
        $row = mysqli_fetch_assoc($result);

$ans = $row["id"];


$sql="INSERT INTO `roomdetails` (`room_owner_id`, `type`, `preferred_block`, `beds`) VALUES ('$ans', '$type' ,'$block', '$beds')";

         $result = mysqli_query($conn, $sql) or trigger_error("Query Failed! SQL: $sql - Error: ".mysqli_error($conn), E_USER_ERROR);


header("location: create.php");











       

    }

    
?>






























<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://fonts.googleapis.com/css2?family=Public+Sans:ital,wght@0,200;0,300;0,400;1,800&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

    <link
    rel="stylesheet"
    href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css"
  />
 <style>

  body{
  font-family: 'Public Sans', sans-serif;
  font-weight: 400;
}

.navbar-brand{
  font-family: 'Public Sans', sans-serif;
  font-weight: 800;
  font-size: 25px;

}

nav{
  color:white;
  background-color: #FC7174;
}

#img{
  width: 40%;
  height: auto;
}

.contt{
    padding: 15%;
    padding-top: 0px;
}


.full-height{
   margin-top: 100px;
   }


   #anii {
  

  animation: backInRight; /* referring directly to the animation's @keyframe declaration */
  animation-duration: 2s; /* don't forget to set a duration! */
}

.card {
  

  animation: pulse; /* referring directly to the animation's @keyframe declaration */
  animation-duration: 2s; /* don't forget to set a duration! */
}

/* [1] The container */

/* [2] Transition property for smooth transformation of images */
.card:hover {
  transform: scale(1.03); /* (150% zoom - Note: if the zoom is too large, it will go outside of the viewport) */
  background-color: #FC7174;
  transition: transform .5s ease;
  color: white;
}






 </style>
  </head>
  <body>
    <nav class="navbar navbar-expand-lg navbar-dark ">
  <div class="container-fluid">
    <a class="navbar-brand" href="dashboard.php"><i><b>Bookbyers</b></i></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" href="find.php">Find Roommates</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" href="moredetails.php">Create a room</a>
        </li>
       
      </ul>
      <span class="navbar-text" style="margin-right:40px">
        Logged in as <?php echo $_SESSION['user_first_name']; ?>
      </span>
      <span class="navbar-text active">
        <a  style="text-decoration: none" href="logout.php">Logout</a>
        
      </span>
    </div>
  </div>
</nav>

<div class="container contt">
<br>
<br>
<p class="h1">Manage Rooms</p>
<hr>
  <div class="row">
    <div class="col">
      <div class="card" style="width: 100%" onclick="myFunction1()">
  <img src="manage.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">Handle Requests</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    
  </div>
</div>
    </div>
    <div class="col">
      <div class="card" style="width: 100%" onclick="myFunction2()">
  <img src="sleep.png" class="card-img-top" alt="...">
  <div class="card-body">
    <h5 class="card-title">View Current Room details</h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
    
  </div>
</div>
    </div>
    
</div>
    </div>
  </div>
</div>



</div>

<script>

function myFunction1() {
  window.location = "http://localhost/vamsi/handle.php";
}
function myFunction2() {
  window.location = "http://localhost/vamsi/currentroom.php";
}





</script>





    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.bundle.min.js" integrity="sha384-JEW9xMcG8R+pH31jmWH6WWP0WintQrMb4s7ZOdauHnUtxwoG2vI5DkLtS3qm9Ekf" crossorigin="anonymous"></script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.1/dist/umd/popper.min.js" integrity="sha384-SR1sx49pcuLnqZUnnPwx6FCym0wLsk5JZuNx2bPPENzswTNFaQU1RDvt3wT4gWFG" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/js/bootstrap.min.js" integrity="sha384-j0CNLUeiqtyaRmlzUHCPZ+Gy5fQu0dQ6eZ/xAww941Ai1SxSY+0EQqNXNE6DZiVc" crossorigin="anonymous"></script>
    -->
  </body>
</html>